# Analysis for cfgUseTransitionScene_false.mp4

Source video: `out\cfgUseTransitionScene_false.mp4`

- duration: 20.54 s
- fps: 24.00

## Detected scene-change timestamps

- #1: 8.500 s (dist=0.656, frame=204) — screenshot: dist/results/screenshots/cfgUseTransitionScene_false_scene_01.png
- #2: 14.000 s (dist=0.664, frame=336) — screenshot: dist/results/screenshots/cfgUseTransitionScene_false_scene_02.png

## Detected black periods

- #1: start 8.500s, end 14.000s, length 5.500s
  - screenshot: dist/results/screenshots/cfgUseTransitionScene_false_black_01.png

## Relevant log excerpts (search results)


## Notes / next steps

- Correlate the scene-change timestamps above with the teleport/reload log timestamps.
- If you want me to create a PR with these results, run this script, commit the dist/results output and tell me or give me permission to open a PR.
