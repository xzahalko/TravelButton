# Analysis for cfgUseTransitionScene_true.mp4

Source video: `out\cfgUseTransitionScene_true.mp4`

- duration: 25.33 s
- fps: 24.00

## Detected scene-change timestamps

- #1: 12.000 s (dist=0.411, frame=288) — screenshot: dist/results/screenshots/cfgUseTransitionScene_true_scene_01.png
- #2: 12.500 s (dist=0.644, frame=300) — screenshot: dist/results/screenshots/cfgUseTransitionScene_true_scene_02.png
- #3: 18.000 s (dist=0.672, frame=432) — screenshot: dist/results/screenshots/cfgUseTransitionScene_true_scene_03.png
- #4: 24.500 s (dist=0.668, frame=588) — screenshot: dist/results/screenshots/cfgUseTransitionScene_true_scene_04.png

## Detected black periods

- #1: start 12.000s, end 18.000s, length 6.000s
  - screenshot: dist/results/screenshots/cfgUseTransitionScene_true_black_01.png
- #2: start 24.500s, end 25.333s, length 0.833s
  - screenshot: dist/results/screenshots/cfgUseTransitionScene_true_black_02.png

## Relevant log excerpts (search results)


## Notes / next steps

- Correlate the scene-change timestamps above with the teleport/reload log timestamps.
- If you want me to create a PR with these results, run this script, commit the dist/results output and tell me or give me permission to open a PR.
