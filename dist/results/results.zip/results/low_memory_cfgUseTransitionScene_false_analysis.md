# Analysis for low_memory_cfgUseTransitionScene_false.mp4

Source video: `out\low_memory_cfgUseTransitionScene_false.mp4`

- duration: 60.00 s
- fps: 24.00

## Detected scene-change timestamps

- #1: 5.500 s (dist=0.425, frame=132) — screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_scene_01.png
- #2: 14.500 s (dist=0.381, frame=348) — screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_scene_02.png
- #3: 23.000 s (dist=0.621, frame=552) — screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_scene_03.png
- #4: 25.500 s (dist=0.503, frame=612) — screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_scene_04.png
- #5: 55.500 s (dist=0.669, frame=1332) — screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_scene_05.png
- #6: 59.500 s (dist=0.685, frame=1428) — screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_scene_06.png

## Detected black periods

- #1: start 23.000s, end 55.500s, length 32.500s
  - screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_black_01.png
- #2: start 59.500s, end 60.000s, length 0.500s
  - screenshot: dist/results/screenshots/low_memory_cfgUseTransitionScene_false_black_02.png

## Relevant log excerpts (search results)


## Notes / next steps

- Correlate the scene-change timestamps above with the teleport/reload log timestamps.
- If you want me to create a PR with these results, run this script, commit the dist/results output and tell me or give me permission to open a PR.
